#include "pch.h"
#include "CppUnitTest.h"
#include "../Calculator/cMain.h"
#include "../Calculator/ButtonFactory.h"


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace CalculatorTests
{
	TEST_CLASS(CalculatorTests)
	{
	public:

		cMain* testing = new cMain();
		ButtonFactory BF = ButtonFactory();
		//binary tests
		TEST_METHOD(buttonFactory1)
		{

			wxButton* thing = BF.Creation(testing, 16, "17", 50, 80);
			Assert::AreEqual(thing->GetId(), 16);


		}


		TEST_METHOD(ButtonFactory2) {
	

			wxButton* Button = BF.Creation(testing, 21, "99", 57, 36);
			Assert::AreEqual(Button->GetLabel(), "99");

		}



		TEST_METHOD(buttonFactory3) {

			wxButton* Button = BF.Creation(testing, 21, "99", 579, 36);
			Assert::AreNotEqual(Button->GetId(), 99);
		}

		TEST_METHOD(BUTTONFACTORY4) {
			wxButton* Button = BF.Creation(testing, 98, "1994", 54, 36);
			Assert::AreEqual(Button->GetLabel(), "1994");
		}

		TEST_METHOD(BUTTONFACTORY5) {
			wxButton* Button = BF.Creation(testing, 999, "12345", 545, 36);
			Assert::AreEqual(Button->GetId(), 999);
		}

		TEST_METHOD(BUTTONFACTORY6) {
			wxButton* Button = BF.Creation(testing, 21, "987654", 575, 36);
			Assert::AreEqual(Button->GetLabel(), "987654");
		}

		TEST_METHOD(BUTTONFACTORY7) {

			wxButton* Button = BF.Creation(testing, 19, "25", 578, 36);
			Assert::AreEqual(Button->GetId(), 19);
		}

		TEST_METHOD(BUTTONFACTORY8) {
			wxButton* Button = BF.Creation(testing, 21, "11", 57, 36);
			Assert::AreNotEqual(Button->GetLabel(), "1");
		}

		TEST_METHOD(BUTTONFACTORY9) {
			wxButton* Button = BF.Creation(testing, 567, "987", 57, 36);
			Assert::AreEqual(Button->GetId(), 567); 
		}

		TEST_METHOD(BUTTONFACTORY_TEN) {
			wxButton* Button = BF.Creation(testing, 21, "9876", 57, 36);
			Assert::AreNotEqual(Button->GetLabel(), "1");
		}
	};
}