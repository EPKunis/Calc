#include "pch.h"
#include "CppUnitTest.h"
#include "../Calculator/CalculatorProcessor.h"


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace CalculatorTests
{
	TEST_CLASS(CalculatorTests)
	{
	public:

		std::string Equation = "";
		std::string E_answer = "";
		//binary tests
		TEST_METHOD(Testing_binary)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();
				
			_processor->SetBaseNumber(89);
			std::string ans = "00000000000000000000000001011001";
			Assert::AreNotEqual(_processor->GetBinary(), ans);
		}
		TEST_METHOD(Testing_binary2)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(890);
			std::string ans = "00000000000000000000000001011001";
			Assert::AreNotEqual(_processor->GetBinary(), ans);
		}
		TEST_METHOD(Testing_binary3)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(2099);
			std::string ans = "00000000000000000000100000110011";

			Assert::AreNotEqual(_processor->GetBinary(), ans);
		}
		
		//hex tests
		TEST_METHOD(Testing_hex)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(87);
			std::string ans = "0x57";
			Assert::AreEqual(_processor->GetHexadecimal() , ans);
		}
		TEST_METHOD(Testing_hex2)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(24);
			std::string ans = "0x37E";
			Assert::AreNotEqual(_processor->GetHexadecimal() , ans);
		}
		TEST_METHOD(Testing_hex3)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(999);
			std::string ans = "0x37E";
			Assert::AreEqual(_processor->GetHexadecimal() , ans);
		}
		
		TEST_METHOD(Addition)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(99);
			double ans = 100;
			Assert::AreEqual(_processor->Add(1), ans);
		}
		TEST_METHOD(Subtract)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();
			
			_processor->SetBaseNumber(76);
			double ans = 56;
			Assert::AreEqual(_processor->Subtract(20), ans);
			
		}
		TEST_METHOD(Multiply)
		{
			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(2);
			double ans = 4;
			Assert::AreEqual(_processor->Multiply(2), ans);
		}

		TEST_METHOD(Divide)
		{

			CalculatorProcessor* _processor = CalculatorProcessor::GetInstance();

			_processor->SetBaseNumber(69);
			double ans = 23;
			Assert::AreEqual(_processor->Divide(3), ans);
		}
	};
}